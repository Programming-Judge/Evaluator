t=int(input())
for _ in range(t):
    flag=True
    n=int(input())
    arr=[int(x) for x in input().split()]
    arr.sort(reverse=True)
    def solve(arr,n):
        left=0
        right=n-1
        c1,c2=0,0
        lsum,rsum=0,0
        while left<=right:
            if c1<c2:
                if lsum>rsum:
                    return True
            if lsum<=rsum:
                lsum+=arr[left]
                left+=1
                c1+=1
            else:
                if c1>=c2:
                    rsum+=arr[right]
                    right-=1
                    c2+=1
        if c1<c2:
                if lsum>rsum:
                    return True
        return False
    if solve(arr,n):
        print("YES")
    else:
        print("NO")
